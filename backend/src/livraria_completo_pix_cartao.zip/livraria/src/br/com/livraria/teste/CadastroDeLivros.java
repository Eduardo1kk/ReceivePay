package br.com.livraria.teste;

import br.com.livraria.Autor;
import br.com.livraria.produtos.Ebook;
import br.com.livraria.produtos.Livro;
import br.com.livraria.produtos.LivroFisico;
import br.com.livraria.produtos.MiniLivro;

public class CadastroDeLivros {
    public static void main(String[] args) {
        Autor autor = new Autor();
        autor.setNome("Rodrigo Turini");
        autor.setEmail("rodrigo.turini@caelum.com.br");
        autor.setCpf("123.456.789-10");

        Livro livro = new LivroFisico(autor);
        livro.setNome("Java 8 Prático");
        livro.setDescricao("Novos recursos da linguagem");
        livro.setValor(59.90);
        livro.setIsbn("978-85-66250-46-6");
        livro.mostrarDetalhes();

        Autor outroAutor = new Autor();
        outroAutor.setNome("Paulo Silveira");
        outroAutor.setEmail("paulo.silveira@caelum.com.br");
        outroAutor.setCpf("987.654.321-00");

        Livro outroLivro = new Ebook(outroAutor);
        outroLivro.setNome("Lógica de Programação");
        outroLivro.setDescricao("Crie seus primeiros programas");
        outroLivro.setValor(29.90);
        outroLivro.setIsbn("978-85-66250-22-0");
        outroLivro.mostrarDetalhes();

        MiniLivro mini = new MiniLivro(autor);
        mini.setNome("Guia de Bolso Java");
        mini.setDescricao("Sintaxe rápida");
        mini.setValor(19.90);
        mini.mostrarDetalhes();

        if (autor.equals(outroAutor)) {
            System.out.println("Autores iguais");
        } else {
            System.out.println("Autores diferentes");
        }
    }
}
