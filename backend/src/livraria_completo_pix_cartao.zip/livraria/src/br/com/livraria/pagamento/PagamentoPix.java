package br.com.livraria.pagamento;

import br.com.livraria.Cliente;
import br.com.livraria.exception.PagamentoRecusadoException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class PagamentoPix implements MetodoPagamento {
    private String chavePixDestino;
    private String nomePagador;
    private String cpfPagador;
    private double percentualDescontoPix;
    private double valorFinalPago;
    private String codigoTransacao;
    private LocalDateTime dataHoraPagamento;

    public PagamentoPix(Cliente cliente, String chavePixDestino) {
        this(chavePixDestino,
             cliente != null ? cliente.getNome() : "Cliente não identificado",
             cliente != null ? cliente.getCpf() : "---");
    }

    public PagamentoPix(String chavePixDestino, String nomePagador, String cpfPagador) {
        this.chavePixDestino = chavePixDestino;
        this.nomePagador = nomePagador;
        this.cpfPagador = cpfPagador;
        this.percentualDescontoPix = 0.05; // 5% de desconto para pagamentos no PIX
    }

    @Override
    public boolean processarPagamento(double valor) {
        if (valor <= 0) {
            throw new PagamentoRecusadoException("O valor do pagamento via PIX deve ser maior que zero.");
        }
        if (chavePixDestino == null || chavePixDestino.trim().isEmpty()) {
            throw new PagamentoRecusadoException("Chave PIX inválida ou não informada.");
        }

        double desconto = valor * percentualDescontoPix;
        this.valorFinalPago = valor - desconto;
        this.codigoTransacao = "E2E-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.dataHoraPagamento = LocalDateTime.now();

        System.out.println("\n[PIX] Iniciando pagamento instantâneo...");
        System.out.printf("[PIX] Valor original: R$ %.2f | Desconto PIX (5%%): -R$ %.2f%n", valor, desconto);
        System.out.printf("[PIX] Valor final debitado: R$ %.2f%n", valorFinalPago);
        System.out.println("[PIX] Pagamento aprovado com sucesso!");
        return true;
    }

    @Override
    public String gerarComprovante() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        return "=========================================\n" +
               "          COMPROVANTE DE PIX             \n" +
               "=========================================\n" +
               "Cliente Pagador: " + nomePagador + " (CPF: " + cpfPagador + ")\n" +
               "Chave Destino: " + chavePixDestino + "\n" +
               String.format("Valor Pago: R$ %.2f (5%% de desconto aplicado)%n", valorFinalPago) +
               "ID Transação: " + codigoTransacao + "\n" +
               "Data/Hora: " + (dataHoraPagamento != null ? dataHoraPagamento.format(fmt) : "-") + "\n" +
               "=========================================";
    }

    @Override
    public String getNomeMetodo() {
        return "PIX";
    }

    public double getValorFinalPago() {
        return valorFinalPago;
    }
}
