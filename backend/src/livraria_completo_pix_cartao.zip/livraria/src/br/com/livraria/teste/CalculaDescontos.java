package br.com.livraria.teste;

import br.com.livraria.compras.GerenciadorDeCupons;

public class CalculaDescontos {
    public static void main(String[] args) {
        GerenciadorDeCupons gerenciador = new GerenciadorDeCupons();

        Double desconto = gerenciador.validaCupom("cab11");

        if (desconto != null) {
            System.out.println("Cupom de desconto válido.");
            System.out.println("Valor R$ " + desconto);
        } else {
            System.out.println("Esse cupom não existe.");
        }
    }
}
