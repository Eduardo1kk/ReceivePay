package br.com.livraria.produtos;

import br.com.livraria.Autor;
import br.com.livraria.exception.AutorNuloException;

public abstract class Livro implements Produto {
    private String nome;
    private String descricao;
    private double valor;
    private String isbn;
    private Autor autor;

    public Livro(Autor autor) {
        if (autor == null) {
            throw new AutorNuloException("O Autor do Livro não pode ser nulo");
        }
        this.autor = autor;
        this.isbn = "000-00-00000-00-0";
    }

    public boolean temAutor() {
        return this.autor != null;
    }

    public void mostrarDetalhes() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        String detalhes = "Mostrando detalhes do livro:\n" +
                "Nome: " + nome + "\n" +
                "Descrição: " + descricao + "\n" +
                String.format("Valor: R$ %.2f\n", valor) +
                "ISBN: " + isbn + "\n";

        if (this.temAutor()) {
            detalhes += "Autor: " + autor.getNome() + " (" + autor.getEmail() + ")\n";
        }
        detalhes += "---";
        return detalhes;
    }

    @Override
    public int compareTo(Produto outro) {
        if (this.getValor() < outro.getValor()) {
            return -1;
        }
        if (this.getValor() > outro.getValor()) {
            return 1;
        }
        return 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        if (valor < 0) {
            throw new IllegalArgumentException("O valor do livro não pode ser negativo.");
        }
        this.valor = valor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Autor getAutor() {
        return autor;
    }

    public void setAutor(Autor autor) {
        this.autor = autor;
    }
}
