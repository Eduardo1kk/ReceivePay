package br.com.livraria.teste;

import br.com.livraria.Autor;
import br.com.livraria.Cliente;
import br.com.livraria.Editora;
import br.com.livraria.compras.CarrinhoDeCompras;
import br.com.livraria.compras.GerenciadorDeCupons;
import br.com.livraria.exception.PagamentoRecusadoException;
import br.com.livraria.pagamento.MetodoPagamento;
import br.com.livraria.pagamento.PagamentoCartaoCredito;
import br.com.livraria.pagamento.PagamentoPix;
import br.com.livraria.produtos.Ebook;
import br.com.livraria.produtos.LivroFisico;
import br.com.livraria.produtos.MiniLivro;
import br.com.livraria.produtos.Produto;
import br.com.livraria.produtos.Revista;
import java.util.Collections;
import java.util.List;

public class RegistroDeVendas {
    public static void main(String[] args) {
        System.out.println("=== 1. CADASTRO DE CLIENTE ===");
        Cliente cliente = new Cliente();
        cliente.setNome("Paulo Fernando");
        cliente.setCpf("123.456.789-09");
        cliente.setEmail("paulo.fernando@email.com");
        cliente.setTelefone("(81) 99999-0000");
        cliente.setEndereco("Recife - PE");
        cliente.mostrarDetalhes();

        System.out.println("=== 2. CADASTRO DE PRODUTOS E CARRINHO ===");
        Autor autor = new Autor();
        autor.setNome("Mauricio Aniche");
        autor.setEmail("mauricio.aniche@caelum.com.br");
        autor.setCpf("111.222.333-44");

        LivroFisico fisico = new LivroFisico(autor);
        fisico.setNome("Test-Driven Development");
        fisico.setDescricao("Teste e Design no Mundo Real");
        fisico.setValor(59.90);

        if (fisico.aplicaDescontoDe10Porcento()) {
            System.out.printf("Valor do Livro Físico com 10%% de desconto: R$ %.2f%n", fisico.getValor());
        }

        Ebook ebook = new Ebook(autor);
        ebook.setNome("Test-Driven Development (Digital)");
        ebook.setDescricao("Versão Ebook");
        ebook.setValor(29.90);
        ebook.setWaterMark(cliente.getEmail());

        MiniLivro mini = new MiniLivro(autor);
        mini.setNome("Resumo TDD");
        mini.setDescricao("Guia rápido de bolso");
        mini.setValor(19.90);

        Editora editora = new Editora();
        editora.setNomeFantasia("DevMedia Books");
        editora.setRazaoSocial("DevMedia Editora LTDA");
        editora.setCnpj("12.345.678/0001-99");

        Revista revista = new Revista();
        revista.setNome("Java Magazine");
        revista.setDescricao("Edição Especial Java 8 e POO");
        revista.setValor(24.90);
        revista.setEditora(editora);
        revista.aplicaDescontoDe(0.10);

        // Criando o carrinho vinculado ao Cliente
        CarrinhoDeCompras carrinhoPix = new CarrinhoDeCompras(cliente);
        carrinhoPix.adiciona(fisico);
        carrinhoPix.adiciona(ebook);
        carrinhoPix.adiciona(mini);
        carrinhoPix.adiciona(revista);

        System.out.println("\n=== 3. ORDENAÇÃO DE PRODUTOS POR PREÇO (Comparable) ===");
        List<Produto> produtos = carrinhoPix.getProdutos();
        Collections.sort(produtos);
        for (Produto produto : produtos) {
            System.out.printf("- Preço ordenado: R$ %.2f%n", produto.getValor());
        }

        System.out.println("\n=== 4. VALIDAÇÃO DE CUPOM DE DESCONTO (HashMap) ===");
        GerenciadorDeCupons gerenciadorCupons = new GerenciadorDeCupons();
        Double descontoCupom = gerenciadorCupons.validaCupom("cab11");
        if (descontoCupom != null) {
            carrinhoPix.aplicarDescontoCupom(descontoCupom);
        }

        System.out.println("\n=== 5. PAGAMENTO VIA PIX ===");
        MetodoPagamento pix = new PagamentoPix(cliente, "livraria@estacio.br");
        carrinhoPix.finalizarCompra(pix);

        System.out.println("\n=== 6. SEGUNDA VENDA: PAGAMENTO VIA CARTÃO DE CRÉDITO ===");
        CarrinhoDeCompras carrinhoCartao = new CarrinhoDeCompras(cliente);
        carrinhoCartao.adiciona(fisico);
        carrinhoCartao.adiciona(ebook);

        MetodoPagamento cartao = new PagamentoCartaoCredito(
                cliente,
                "5432 1098 7654 3210",
                "Mastercard",
                3, // 3x sem juros
                500.00 // limite disponível
        );
        carrinhoCartao.finalizarCompra(cartao);

        System.out.println("\n=== 7. TESTE DE EXCEÇÃO (LIMITE INSUFICIENTE NO CARTÃO) ===");
        try {
            MetodoPagamento cartaoSemLimite = new PagamentoCartaoCredito(
                    cliente,
                    "4111 2222 3333 4444",
                    "Visa",
                    6, // 6x com juros
                    30.00 // limite abaixo do valor da compra
            );
            carrinhoCartao.finalizarCompra(cartaoSemLimite);
        } catch (PagamentoRecusadoException e) {
            System.out.println("[EXCEÇÃO CAPTURADA] " + e.getMessage());
        }
    }
}
