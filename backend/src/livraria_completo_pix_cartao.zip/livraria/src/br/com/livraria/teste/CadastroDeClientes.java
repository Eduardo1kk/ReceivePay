package br.com.livraria.teste;

import br.com.livraria.Cliente;
import br.com.livraria.ValidadorCpf;
import br.com.livraria.exception.CpfInvalidoException;

public class CadastroDeClientes {
    public static void main(String[] args) {
        System.out.println("=== 1. CÁLCULO DE DÍGITOS VERIFICADORES DE CPF ===");
        String base1 = "123456789";
        String dv1 = ValidadorCpf.calcularDigitosVerificadores(base1);
        String cpfGerado1 = ValidadorCpf.gerarCpfValidoFormatado(base1);
        System.out.println("Base 9 dígitos: " + base1 + " -> Dígitos calculados: " + dv1 + " -> CPF Completo: " + cpfGerado1);

        String base2 = "111444777";
        String dv2 = ValidadorCpf.calcularDigitosVerificadores(base2);
        String cpfGerado2 = ValidadorCpf.gerarCpfValidoFormatado(base2);
        System.out.println("Base 9 dígitos: " + base2 + " -> Dígitos calculados: " + dv2 + " -> CPF Completo: " + cpfGerado2);

        System.out.println("\n=== 2. CADASTRANDO CLIENTES COM CPFs VÁLIDOS ===");
        Cliente cliente1 = new Cliente();
        cliente1.setNome("Paulo Fernando");
        cliente1.setCpf("12345678909"); // Aceita sem pontuação e formata automaticamente para 123.456.789-09
        cliente1.setEmail("paulo.fernando@email.com");
        cliente1.setTelefone("(81) 99999-0000");
        cliente1.setEndereco("Recife - PE");
        cliente1.mostrarDetalhes();

        Cliente cliente2 = new Cliente("Maria Silva", "111.444.777-35", "maria.silva@email.com");
        cliente2.setTelefone("(81) 98888-1111");
        cliente2.setEndereco("Olinda - PE");
        cliente2.mostrarDetalhes();

        System.out.println("=== 3. COMPARAÇÃO DE CLIENTES (equals) ===");
        Cliente clienteDuplicado = new Cliente("Paulo F.", "123.456.789-09", "outro@email.com");
        System.out.println("Cliente 1 igual a Cliente 2? " + cliente1.equals(cliente2));
        System.out.println("Cliente 1 igual a Cliente Duplicado (mesmo CPF)? " + cliente1.equals(clienteDuplicado));

        System.out.println("\n=== 4. TESTANDO BLOQUEIO DE CPFs INVÁLIDOS ===");
        String[] cpfsInvalidos = {"123.456.789-00", "111.111.111-11", "12345"};
        for (String cpfTeste : cpfsInvalidos) {
            try {
                Cliente clienteInvalido = new Cliente("Teste Inválido", cpfTeste, "teste@email.com");
                clienteInvalido.mostrarDetalhes();
            } catch (CpfInvalidoException e) {
                System.out.println("[EXCEÇÃO CAPTURADA] " + e.getMessage());
            }
        }
    }
}
