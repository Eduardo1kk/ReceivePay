package br.com.livraria;

public class ValidadorCpf {

    /**
     * Valida um CPF aplicando o algoritmo oficial de Módulo 11 da Receita Federal.
     */
    public static boolean isCpfValido(String cpf) {
        if (cpf == null) {
            return false;
        }

        // Remove pontos, traços e espaços
        String numeros = cpf.replaceAll("\\D", "");

        // Deve ter exatamente 11 dígitos e não pode ter todos os dígitos iguais (ex: 111.111.111-11)
        if (numeros.length() != 11 || numeros.matches("(\\d)\\1{10}")) {
            return false;
        }

        String noveDigitos = numeros.substring(0, 9);
        String digitosCalculados = calcularDigitosVerificadores(noveDigitos);

        return numeros.substring(9, 11).equals(digitosCalculados);
    }

    /**
     * Calcula os 2 dígitos verificadores a partir dos 9 primeiros dígitos do CPF.
     */
    public static String calcularDigitosVerificadores(String novePrimeirosDigitos) {
        if (novePrimeirosDigitos == null) {
            throw new IllegalArgumentException("Os 9 dígitos base não podem ser nulos.");
        }
        String base = novePrimeirosDigitos.replaceAll("\\D", "");
        if (base.length() != 9) {
            throw new IllegalArgumentException("Informe exatamente os 9 primeiros dígitos para calcular o CPF.");
        }

        // Cálculo do 1º dígito verificador (pesos de 10 a 2)
        int soma1 = 0;
        for (int i = 0; i < 9; i++) {
            int digito = Character.getNumericValue(base.charAt(i));
            soma1 += digito * (10 - i);
        }
        int resto1 = (soma1 * 10) % 11;
        int digito1 = (resto1 == 10 || resto1 == 11) ? 0 : resto1;

        // Cálculo do 2º dígito verificador (pesos de 11 a 2, incluindo o 1º dígito verificador)
        String baseComPrimeiroDigito = base + digito1;
        int soma2 = 0;
        for (int i = 0; i < 10; i++) {
            int digito = Character.getNumericValue(baseComPrimeiroDigito.charAt(i));
            soma2 += digito * (11 - i);
        }
        int resto2 = (soma2 * 10) % 11;
        int digito2 = (resto2 == 10 || resto2 == 11) ? 0 : resto2;

        return "" + digito1 + digito2;
    }

    /**
     * Gera um CPF válido e já formatado (XXX.XXX.XXX-XX) a partir de 9 dígitos base.
     */
    public static String gerarCpfValidoFormatado(String novePrimeirosDigitos) {
        String base = novePrimeirosDigitos.replaceAll("\\D", "");
        String dv = calcularDigitosVerificadores(base);
        return formatarCpf(base + dv);
    }

    /**
     * Formata uma string de 11 dígitos no padrão XXX.XXX.XXX-XX.
     */
    public static String formatarCpf(String cpf) {
        if (cpf == null) {
            return null;
        }
        String numeros = cpf.replaceAll("\\D", "");
        if (numeros.length() != 11) {
            return cpf;
        }
        return numeros.substring(0, 3) + "." +
               numeros.substring(3, 6) + "." +
               numeros.substring(6, 9) + "-" +
               numeros.substring(9, 11);
    }
}
