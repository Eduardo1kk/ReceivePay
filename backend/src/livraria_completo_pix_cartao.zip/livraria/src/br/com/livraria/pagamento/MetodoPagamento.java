package br.com.livraria.pagamento;

public interface MetodoPagamento {
    boolean processarPagamento(double valor);
    String gerarComprovante();
    String getNomeMetodo();
}
