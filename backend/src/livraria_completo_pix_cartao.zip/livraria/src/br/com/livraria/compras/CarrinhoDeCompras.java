package br.com.livraria.compras;

import br.com.livraria.Cliente;
import br.com.livraria.pagamento.MetodoPagamento;
import br.com.livraria.produtos.Produto;
import java.util.ArrayList;
import java.util.List;

public class CarrinhoDeCompras {
    private Cliente cliente;
    private double total;
    private List<Produto> produtos;

    public CarrinhoDeCompras() {
        this.produtos = new ArrayList<Produto>();
    }

    public CarrinhoDeCompras(Cliente cliente) {
        this();
        this.cliente = cliente;
    }

    public void adiciona(Produto produto) {
        if (produto == null) {
            throw new IllegalArgumentException("Produto não pode ser nulo.");
        }
        System.out.println("Adicionando ao carrinho: " + produto);
        this.produtos.add(produto);
        this.total += produto.getValor();
    }

    public void remove(int posicao) {
        if (posicao >= 0 && posicao < this.produtos.size()) {
            Produto removido = this.produtos.remove(posicao);
            this.total -= removido.getValor();
        }
    }

    public void aplicarDescontoCupom(Double valorDesconto) {
        if (valorDesconto != null && valorDesconto > 0 && valorDesconto < this.total) {
            this.total -= valorDesconto;
            System.out.printf("Cupom aplicado no carrinho: -R$ %.2f | Novo subtotal: R$ %.2f%n", valorDesconto, this.total);
        }
    }

    public boolean finalizarCompra(MetodoPagamento metodoPagamento) {
        if (this.produtos.isEmpty()) {
            System.out.println("O carrinho está vazio. Adicione produtos antes de finalizar a compra.");
            return false;
        }
        if (this.cliente != null) {
            System.out.println("\nCliente da compra: " + this.cliente);
        }
        System.out.printf("Iniciando checkout via %s (Subtotal do carrinho: R$ %.2f)...%n",
                metodoPagamento.getNomeMetodo(), this.total);

        boolean aprovado = metodoPagamento.processarPagamento(this.total);
        if (aprovado) {
            System.out.println(metodoPagamento.gerarComprovante());
        }
        return aprovado;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double getTotal() {
        return total;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }
}
