package br.com.livraria;

import br.com.livraria.exception.CpfInvalidoException;

public class Cliente {
    private String nome;
    private String cpf;
    private String email;
    private String telefone;
    private String endereco;

    public Cliente() {
    }

    public Cliente(String nome, String cpf, String email) {
        this.nome = nome;
        this.setCpf(cpf);
        this.email = email;
    }

    public void mostrarDetalhes() {
        System.out.println("Mostrando detalhes do cliente:");
        System.out.println("Nome: " + nome);
        System.out.println("CPF: " + cpf + " (Válido: " + (ValidadorCpf.isCpfValido(cpf) ? "Sim" : "Não") + ")");
        System.out.println("Email: " + email);
        if (telefone != null && !telefone.isEmpty()) {
            System.out.println("Telefone: " + telefone);
        }
        if (endereco != null && !endereco.isEmpty()) {
            System.out.println("Endereço: " + endereco);
        }
        System.out.println("---");
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (!ValidadorCpf.isCpfValido(cpf)) {
            throw new CpfInvalidoException("CPF inválido informado para o cliente: " + cpf);
        }
        this.cpf = ValidadorCpf.formatarCpf(cpf);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Cliente)) {
            return false;
        }
        Cliente outro = (Cliente) obj;
        return this.cpf != null && this.cpf.equals(outro.cpf);
    }

    @Override
    public String toString() {
        return nome + " (CPF: " + cpf + " | Email: " + email + ")";
    }
}
