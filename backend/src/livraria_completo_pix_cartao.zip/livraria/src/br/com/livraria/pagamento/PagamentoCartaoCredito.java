package br.com.livraria.pagamento;

import br.com.livraria.Cliente;
import br.com.livraria.exception.PagamentoRecusadoException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class PagamentoCartaoCredito implements MetodoPagamento {
    private String nomeTitular;
    private String cpfTitular;
    private String numeroCartao;
    private String bandeira;
    private int parcelas;
    private double limiteDisponivel;
    private double valorFinalPago;
    private double valorParcela;
    private String codigoAutorizacao;
    private LocalDateTime dataHoraPagamento;

    public PagamentoCartaoCredito(Cliente cliente, String numeroCartao, String bandeira, int parcelas, double limiteDisponivel) {
        this(cliente != null ? cliente.getNome() : "Titular não identificado",
             numeroCartao, bandeira, parcelas, limiteDisponivel);
        this.cpfTitular = cliente != null ? cliente.getCpf() : null;
    }

    public PagamentoCartaoCredito(String nomeTitular, String numeroCartao, String bandeira, int parcelas, double limiteDisponivel) {
        this.nomeTitular = nomeTitular;
        this.numeroCartao = numeroCartao;
        this.bandeira = bandeira;
        this.parcelas = parcelas;
        this.limiteDisponivel = limiteDisponivel;
    }

    @Override
    public boolean processarPagamento(double valor) {
        if (valor <= 0) {
            throw new PagamentoRecusadoException("O valor da compra no cartão deve ser maior que zero.");
        }
        if (numeroCartao == null || numeroCartao.replaceAll("\\D", "").length() < 12) {
            throw new PagamentoRecusadoException("Número de cartão de crédito inválido.");
        }
        if (parcelas < 1 || parcelas > 12) {
            throw new PagamentoRecusadoException("Número de parcelas inválido (permitido de 1x a 12x).");
        }

        // Regra de negócio: até 3x sem juros; de 4x a 12x acréscimo de 2% ao mês (juros simples)
        if (parcelas > 3) {
            double taxaJuros = 0.02 * parcelas;
            this.valorFinalPago = valor * (1 + taxaJuros);
        } else {
            this.valorFinalPago = valor;
        }

        if (this.valorFinalPago > this.limiteDisponivel) {
            throw new PagamentoRecusadoException(
                String.format("Saldo/Limite insuficiente no cartão. Valor: R$ %.2f | Limite disponível: R$ %.2f",
                        this.valorFinalPago, this.limiteDisponivel)
            );
        }

        this.limiteDisponivel -= this.valorFinalPago;
        this.valorParcela = this.valorFinalPago / this.parcelas;
        this.codigoAutorizacao = "AUT-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        this.dataHoraPagamento = LocalDateTime.now();

        System.out.println("\n[CARTÃO DE CRÉDITO] Processando transação...");
        System.out.printf("[CARTÃO DE CRÉDITO] Bandeira: %s | Parcelamento: %dx de R$ %.2f%n",
                bandeira, parcelas, valorParcela);
        System.out.println("[CARTÃO DE CRÉDITO] Transação autorizada com sucesso!");
        return true;
    }

    private String getCartaoMascarado() {
        String limpo = numeroCartao.replaceAll("\\D", "");
        if (limpo.length() >= 4) {
            return "**** **** **** " + limpo.substring(limpo.length() - 4);
        }
        return "****";
    }

    @Override
    public String gerarComprovante() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String infoTitular = nomeTitular + (cpfTitular != null ? " (CPF: " + cpfTitular + ")" : "");
        return "=========================================\n" +
               "    COMPROVANTE - CARTÃO DE CRÉDITO      \n" +
               "=========================================\n" +
               "Cliente Titular: " + infoTitular + "\n" +
               "Cartão: " + getCartaoMascarado() + " (" + bandeira + ")\n" +
               String.format("Valor Total: R$ %.2f (%dx de R$ %.2f)%n", valorFinalPago, parcelas, valorParcela) +
               String.format("Limite Restante: R$ %.2f%n", limiteDisponivel) +
               "Autorização: " + codigoAutorizacao + "\n" +
               "Data/Hora: " + (dataHoraPagamento != null ? dataHoraPagamento.format(fmt) : "-") + "\n" +
               "=========================================";
    }

    @Override
    public String getNomeMetodo() {
        return "Cartão de Crédito (" + bandeira + ")";
    }
}
